<?php

namespace App\Tasks;

abstract class Task
{
    abstract public function handle();
}
