<?php

namespace App\Events;

abstract class Event
{
    abstract public function getName();
}